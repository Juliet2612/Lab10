#include <stdarg.h>
#include <stdio.h>

int sumaI(int n, ...) {
    va_list app;
    int sum = 0;
    int arg;
    va_start(app, n);
    for (int i = 0; i < n; i++) {
        arg = va_arg(app, int);
        sum += arg;
    }
    va_end(app);
    return sum;
}
float sumaF(float x, int n, ...) {
    va_list app;
    float sum = 0.0f;
    float arg;
    va_start(app, n);
    for (int i = 0; i < n; i++) {
        arg = va_arg(app, double);


        sum += arg;
    }
    va_end(app);
    return sum + x;
}
int main() {
    float suma1 = sumaF(100.0f, 3, 1.1, 2.2, 3.3);
    float suma2 = sumaF(10.0f, 5, 2.0f, 4.0f, 8.0f, 16.0f, 32.0f);
    int suma3 = sumaI(5, 1, 2, 3, 4, 5);
    int suma4 = sumaI(6, 1, 2, 3, 4, 5, -7);
    printf("Suma wynosi %.2f\n", suma1);
    printf("Suma wynosi %.2f\n", suma2);
    printf("Suma wynosi %d\n", suma3);
    printf("Suma wynosi %d\n", suma4);
    fflush(stdin);
    getchar();
    return 0;
}