#include <stdio.h>
#include <windows.h>
void reverseArr(int arr[], int n) {
    for (int low = 0, high = n - 1; low < high; low++, high--) {
        int temp = arr[low];
        arr[low] = arr[high];
        arr[high] = temp;
    }
}

void printArr(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf(" % d ", arr[i]);
    }
}

void readArr(int arr[], int n) {
    printf("\nPodaj %d liczb\n", n);
    fflush(stdin);
    for (int i = 0; i < n; i++) {
        printf("a[%d]: ", i);

        scanf("%d", (arr + i));
    }
}
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    printf("Tablica 1-wymiarowa o zmiennym rozmiarze\n");
    int n;
    printf("Podaj rozmiar tablicy: ");
    fflush(stdin);
    scanf("%d", &n);
    int a[n];
    readArr(a, n);
    printf("Liczby wprowadzone: ");
    printArr(a, n);
    reverseArr(a, n);
    printf("\nLiczby wspak:");
    printArr(a, n);
    printf("\n\nNasiśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}