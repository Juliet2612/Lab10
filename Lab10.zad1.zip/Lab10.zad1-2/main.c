#include <stdio.h>
#include <windows.h>
unsigned long long int factorial(unsigned int n);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    for (unsigned int i = 0; i <= 21; ++i) {
        printf("%u! = %llu\n", i, factorial(i));
    }
    fflush(stdin);
    getchar();
}
unsigned long long int factorial(unsigned int n) {
    if (n <= 1) {
        return 1;
    } else {
        return (n * factorial(n - 1));
    }
}

