#include <stdio.h>
#include <windows.h>
#define ROW 5
#define COL 2
#define N 10
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);

    float matrixA[ROW][COL] = {{1}, {3.5, 7.0}, {1.5, 2.5}};

    puts("\nmatrixA - tablica dwuwymiarowa");
    for (int i = 0; i < ROW; i++)
        for (int j = 0; j < COL; j++)
            printf("m[%d,%d] = %5.1f\n", i, j, matrixA[i][j]);
    fflush(stdin);
    getchar();

    int unitMatrix[N][N];
    for (int row = 0; row < N; row++)
        for (int col = 0; col < N; col++)
            if (row == col)
                unitMatrix[row][col] = 1;
            else
                unitMatrix[row][col] = 0;

    puts("unitMatrix - macierz jednostkowa");
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            printf("%3d", unitMatrix[i][j]);
            if (j == N - 1)printf("\n");
        }
    fflush(stdin);
    getchar();

    puts("Przykład tablicy 2D z błędami indeksów!");
    float matrixB[5][2] = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {8, 9}};
    printf("%5.1f\n", matrixB[1][2]);
    printf("%5.1f\n", matrixB[6][3]);
    fflush(stdin);
    printf("\nNaciśnij Enter, aby zakończyć..");
    getchar();
    return 0;
}