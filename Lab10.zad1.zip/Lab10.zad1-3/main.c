#include <stdio.h>
#include <windows.h>
#include <iso646.h>
unsigned long long int factorial(unsigned int n);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    int n, l;
    do {
        fflush(stdin);
        printf("\nPodaj n [1..21]: ");
        l = scanf("%d", &n);
    } while ((n < 1) or (n > 21) or (l == 0));
    for (unsigned int i = 0; i <= n; ++i) {
        printf("%u! = %llu\n", i, factorial(i));
    }
    fflush(stdin);
    getchar();
}
unsigned long long factorial(unsigned int n) {
    return (n > 1) ? n * factorial(n - 1) : 1ull;
}