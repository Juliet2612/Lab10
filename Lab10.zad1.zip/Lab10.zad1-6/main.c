#include <stdio.h>
#include <windows.h>
int sum_2D(int, int m, int matrix[][m]);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    printf("Tablica 2-wymiarowa jako parametr funkcji\n");
    int a[3][2] = {{1, 2}, {3, 4},{5, 6}};
    int b[5][2] = {1, 1, 1, 1, 1, 1, 1};
    int c[4][3] = {{1, 2, 3},{4, 5, 6},{7, 8, 9}};
    printf("Suma a[3][2]: %d\n", sum_2D(3, 2, a));
    printf("Suma b[5][2]: %d\n", sum_2D(5, 2, b));
    printf("Suma c[4][3]: %d\n", sum_2D(4, 3, c));
    printf("Suma c[2][3]: %d\n", sum_2D(2, 3, c));
    printf("Suma c[3][2]: %d\n", sum_2D(3, 3, c));
    printf("\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}

int sum_2D(int n, int m, int matrix[n][m]) {
    int sum = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            sum += matrix[i][j];
    return sum;
}